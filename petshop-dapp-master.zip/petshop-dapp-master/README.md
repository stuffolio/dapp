
A simple DAPP for a virtual petshop.

Based on [Truffle tutorial](https://truffleframework.com/tutorials/pet-shop)

Be sure Ganache is running

## Run
    truffle compile
    truffle migrate
    truffle test
    npm run dev
